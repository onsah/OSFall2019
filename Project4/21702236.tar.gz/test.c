#include <assert.h>
#include <stdio.h>
#include "simplefs.h"

int main() {
    // 2^21 bytes
    assert(sizeof(Block) == BLOCK_SIZE);

    printf("Test succeeded :)\n");

    /* sfs_mount("test_disk");

    int fd = sfs_open("onur", 0);

    char buf[50];
    sfs_read(fd, buf, 10);

    printf("read: %s\n", buf);

    sfs_umount(); */
}