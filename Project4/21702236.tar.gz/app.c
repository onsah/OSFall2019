#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "simplefs.h"

int main() {
   /*  printf("Size of int64t: %ld\n", sizeof(int64_t));
    printf("Size of a directory entry: %ld\n", sizeof(DirEntry));
    printf("Size of a FAT block: %ld\n", sizeof(int64_t[FAT_PER_BLOCK]));
    printf("Size of a block: %ld\n", sizeof(Block)); */

    create_vdisk("test_disk", 21);

    if (sfs_format("test_disk") == -1) {
        printf("Format failed\n");
        exit(1);
    }

    sfs_mount("test_disk");

    sfs_create("onur");

    int fd = sfs_open("onur", 1);

    int size = 8192;

    char *ptr = malloc(size);

    sfs_append(fd, ptr, size);

    sfs_close(fd);

    fd = sfs_open("onur", 0);

    sfs_read(fd, ptr, size);

    sfs_umount();
    /* printf("Mount: %d\n", sfs_mount("test_disk") == 0);

    sfs_create("onur");
    sfs_create("onur");

    sfs_open("edward", 0);
    int onur_fd = sfs_open("onur", 1);

    char *text = "hello world";
    char *text2 = " onur";
    char *ptr = malloc(1028);
    sfs_append(onur_fd, text, strlen(text));
    sfs_append(onur_fd, ptr, 1028);

    sfs_close(onur_fd);
    onur_fd = sfs_open("onur", 0);

    char buf[30];
    sfs_read(onur_fd, buf, strlen(text));

    printf("Buffer: %s\n", buf);

    sfs_create("dell");

    int dell_fd = sfs_open("dell", 1);

    sfs_append(dell_fd, text, strlen(text) + 1);

    sfs_close(dell_fd);

    dell_fd = sfs_open("dell", 0);

    char output[50];
    sfs_read(dell_fd, output, strlen(text) + 1);

    printf("dell: %s\n", output);

    sfs_umount(); */
}