name: Onur Şahin
ID: 21702236

random inputs created with the following python program:

./rand.py

import random

def gen(n):
    for i in range(n):
        print(random.randint(1, 100_000_000))

gen(1_000_000)